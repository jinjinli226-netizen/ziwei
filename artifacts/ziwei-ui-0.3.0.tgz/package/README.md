# @ziwei/ui

紫薇映界的 Vue 3 组件库与设计令牌。它服务于紫薇中控，也为后续官网、活动页和运营工具提供统一的视觉基础。

## 安装

### 内部项目：安装本地包

在组件库仓库根目录执行：

```sh
npm run pack:ui
```

命令会先执行 `prepack` 构建组件库，再生成 `artifacts/ziwei-ui-0.3.0.tgz`。在其他项目中安装这个包：

```sh
npm install "../抖音数字员工/artifacts/ziwei-ui-0.3.0.tgz" vue
```

组件库要求宿主项目使用 Vue 3。每次更新组件后重新执行 `npm run pack:ui`，再在使用方重新安装新的 tarball。

### 团队 npm 源：发布后安装

如果团队有私有 npm 源，在仓库根目录执行：

```sh
npm publish ./packages/ziwei-ui --registry=https://your-registry.example.com
```

使用方配置同一个 registry 后安装：

```sh
npm install @ziwei/ui@0.3.0 --registry=https://your-registry.example.com
```

## 使用

```sh
npm install @ziwei/ui vue
```

```ts
import { ZiButton, ZiCard, ZiStatusTag } from '@ziwei/ui'
import '@ziwei/ui/style.css'
```

```vue
<ZiCard>
  <ZiStatusTag status="online" label="在线" dot />
  <ZiButton variant="primary">保存</ZiButton>
</ZiCard>
```

也可以在入口文件统一引入样式：

```ts
// src/main.ts
import '@ziwei/ui/style.css'
```

组件按需导入即可，组件库不会重复打包 Vue：

```ts
import { ZiButton, ZiModal } from '@ziwei/ui'
```

## 企业级组件

- 基础：`ZiButton`、`ZiIcon`、`ZiCard`、`ZiAvatar`、`ZiStatusTag`、`ZiProgress`
- 内容：`ZiMetricCard`、`ZiEmptyState`、`ZiModal`、`ZiToast`、`ZiSkeleton`
- 表单：`ZiFormField`、`ZiInput`、`ZiSelect`、`ZiTextarea`、`ZiCheckbox`、`ZiSwitch`
- 导航：`ZiTabs`、`ZiPagination`
- 布局：`ZiContainer`、`ZiStack`、`ZiGrid`、`ZiDivider`、`ZiSection`
- 反馈：`ZiAlert`、`ZiBanner`、`ZiResult`、`ZiLoading`、`ZiErrorState`
- 弹层：`ZiTooltip`、`ZiPopover`、`ZiDropdown`、`ZiDropdownMenu`、`ZiDrawer`、`ZiConfirmDialog`、`ZiCommandPalette`
- 数据：`ZiTable`、`ZiList`、`ZiDescriptionList`、`ZiTimeline`
- 表单：`ZiRadio`、`ZiRadioGroup`、`ZiSearchInput`、`ZiNumberInput`、`ZiDatePicker`、`ZiUpload`
- 工作台：`ZiBreadcrumb`、`ZiSteps`、`ZiConfigProvider`、`ZiThemeProvider`
- 高级：`ZiTree`、`ZiVirtualList`、`ZiToastProvider`

全局通知服务：

```ts
import { useZiweiToast } from '@ziwei/ui'

const toast = useZiweiToast()
toast.show({ title: '保存成功', message: '配置已更新。', tone: 'positive' })
```

`ZiToastProvider` 放在应用根部时会自动渲染通知队列；`ZiTable` 支持搜索、排序、加载态和分页，`ZiTree` 支持展开、选择和勾选，`ZiVirtualList` 用于固定高度的大列表。

组件使用 `ziwei-` 前缀，设计令牌使用 `--ziwei-` 前缀，避免和宿主站点的 CSS 冲突。Vue 只作为 peer dependency，不会被组件库重复打包。

## 本地构建

在仓库根目录执行：

```sh
npm exec vue-tsc -- -p packages/ziwei-ui/tsconfig.build.json
npm exec vite -- build -c packages/ziwei-ui/vite.config.ts
```

正式接入包管理工作区后，可直接使用包内的 `npm run build`。